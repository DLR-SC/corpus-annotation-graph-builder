import cag.graph_framework.graph.nodes as parent_node



class SampleNode(parent_nodes.GenericOOSNode):
    _fields = {
        "text": parent_nodes.Field(),
        **parent_nodes.GenericOOSNode._fields
    }

    def __init__(self, database, jsonData):
        super().__init__(database, jsonData)
        self.ensureFulltextIndex(["text"])
        self.ensureHashIndex(["text"])

