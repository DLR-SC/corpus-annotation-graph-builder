
from cag.graph_framework.graph.nodes import GenericOOSNode, Field


"""OOS NODES RELEVANT FOR OPEN ALEX CORPUS"""

class ASampleNode(GenericOOSNode):
    _fields = {
        'name': Field(),
        **GenericOOSNode._fields
    }


